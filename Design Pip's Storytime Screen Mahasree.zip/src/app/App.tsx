import { useState } from "react";
import { motion } from "motion/react";
import { BookOpen, Star, Volume2, ChevronRight } from "lucide-react";

// {/* MARKER-MAKE-KIT-INVOKED */}
// {/* MARKER-MAKE-KIT-DISCOVERY-READ */}

const QUIZ_OPTIONS = [
  { label: "Red", bg: "#ff6b6b", shadow: "#c94b4b", text: "#fff" },
  { label: "Green", bg: "#6bcb77", shadow: "#4a9a55", text: "#fff" },
  { label: "Blue", bg: "#4da6ff", shadow: "#2a7ecc", text: "#fff" },
  { label: "Yellow", bg: "#ffd166", shadow: "#c9a332", text: "#3a2856" },
];

function PipRobot() {
  return (
    <svg
      viewBox="0 0 120 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full"
      aria-label="Pip the friendly robot"
    >
      {/* Antenna */}
      <rect x="57" y="2" width="6" height="18" rx="3" fill="#a78bfa" />
      <circle cx="60" cy="2" r="6" fill="#ffd166" stroke="#fff" strokeWidth="2" />

      {/* Head */}
      <rect x="20" y="18" width="80" height="60" rx="22" fill="#c4b5fd" stroke="#fff" strokeWidth="3" />

      {/* Screen / face area */}
      <rect x="28" y="26" width="64" height="44" rx="14" fill="#ede9fe" />

      {/* Eyes */}
      <ellipse cx="45" cy="46" rx="10" ry="11" fill="#fff" />
      <ellipse cx="75" cy="46" rx="10" ry="11" fill="#fff" />
      <circle cx="47" cy="47" r="6" fill="#4da6ff" />
      <circle cx="73" cy="47" r="6" fill="#4da6ff" />
      <circle cx="49" cy="45" r="2.5" fill="#1a1a2e" />
      <circle cx="75" cy="45" r="2.5" fill="#1a1a2e" />
      {/* Eye shine */}
      <circle cx="51" cy="43" r="1.5" fill="#fff" />
      <circle cx="77" cy="43" r="1.5" fill="#fff" />

      {/* Smile */}
      <path
        d="M43 60 Q60 72 77 60"
        stroke="#7c3aed"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      />
      {/* Cheek blush */}
      <ellipse cx="34" cy="59" rx="6" ry="4" fill="#ffb3c6" opacity="0.6" />
      <ellipse cx="86" cy="59" rx="6" ry="4" fill="#ffb3c6" opacity="0.6" />

      {/* Ear / side buttons */}
      <rect x="8" y="36" width="12" height="10" rx="5" fill="#a78bfa" stroke="#fff" strokeWidth="2" />
      <rect x="100" y="36" width="12" height="10" rx="5" fill="#a78bfa" stroke="#fff" strokeWidth="2" />

      {/* Neck */}
      <rect x="50" y="78" width="20" height="10" rx="4" fill="#c4b5fd" />

      {/* Body */}
      <rect x="22" y="88" width="76" height="48" rx="18" fill="#c4b5fd" stroke="#fff" strokeWidth="3" />

      {/* Chest panel */}
      <rect x="34" y="96" width="52" height="32" rx="10" fill="#ede9fe" />

      {/* Gear icon on chest */}
      <circle cx="60" cy="112" r="10" fill="#fff" stroke="#a78bfa" strokeWidth="2.5" />
      <circle cx="60" cy="112" r="5" fill="#4da6ff" />
      {/* Gear teeth */}
      {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
        <rect
          key={i}
          x="57"
          y="99"
          width="6"
          height="4"
          rx="1.5"
          fill="#a78bfa"
          transform={`rotate(${angle} 60 112)`}
        />
      ))}

      {/* Arms */}
      <rect x="0" y="92" width="22" height="12" rx="6" fill="#c4b5fd" stroke="#fff" strokeWidth="2" />
      <rect x="98" y="92" width="22" height="12" rx="6" fill="#c4b5fd" stroke="#fff" strokeWidth="2" />

      {/* Feet */}
      <rect x="30" y="132" width="24" height="10" rx="5" fill="#a78bfa" stroke="#fff" strokeWidth="2" />
      <rect x="66" y="132" width="24" height="10" rx="5" fill="#a78bfa" stroke="#fff" strokeWidth="2" />
    </svg>
  );
}

function Cloud({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 80 40" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-hidden="true">
      <ellipse cx="40" cy="28" rx="34" ry="16" fill="white" opacity="0.85" />
      <ellipse cx="26" cy="24" rx="16" ry="14" fill="white" opacity="0.85" />
      <ellipse cx="52" cy="22" rx="14" ry="13" fill="white" opacity="0.85" />
    </svg>
  );
}

function StarDecor({ className, color = "#ffd166" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg" className={className} aria-hidden="true">
      <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z" />
    </svg>
  );
}

export default function App() {
  const [selected, setSelected] = useState<string | null>(null);
  const [revealed, setRevealed] = useState(false);

  const handleAnswer = (label: string) => {
    if (revealed) return;
    setSelected(label);
    setRevealed(true);
  };

  const isCorrect = selected === "Blue";

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "linear-gradient(160deg, #fdf4ff 0%, #e8f4ff 50%, #fff5f0 100%)", fontFamily: "'Nunito', sans-serif" }}
    >
      {/* Mobile frame */}
      <div
        className="relative w-full max-w-sm overflow-hidden rounded-[2.5rem] shadow-2xl"
        style={{ background: "linear-gradient(160deg, #fdf4ff 0%, #e8f4ff 60%, #fff5f0 100%)", minHeight: "780px" }}
      >
        {/* Decorative background layer */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <Cloud className="absolute -top-2 -left-4 w-32 opacity-70" />
          <Cloud className="absolute top-8 right-0 w-24 opacity-60" />
          <Cloud className="absolute top-48 -left-6 w-20 opacity-40" />
          <StarDecor className="absolute top-14 left-6 w-6 h-6" color="#ffd166" />
          <StarDecor className="absolute top-20 right-8 w-4 h-4" color="#a78bfa" />
          <StarDecor className="absolute top-36 right-14 w-5 h-5" color="#ff6b5b" />
          <StarDecor className="absolute top-52 right-4 w-4 h-4" color="#ffd166" />
          <StarDecor className="absolute bottom-32 left-4 w-5 h-5" color="#4da6ff" />
          <StarDecor className="absolute bottom-48 right-6 w-4 h-4" color="#6bcb77" />
          {/* Bubbles */}
          <div className="absolute top-40 left-2 w-8 h-8 rounded-full opacity-20" style={{ background: "#a78bfa" }} />
          <div className="absolute top-64 right-0 w-12 h-12 rounded-full opacity-15" style={{ background: "#4da6ff" }} />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col px-5 pt-8 pb-8 gap-5">

          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <p style={{ color: "#7b5ea7", fontSize: "0.78rem", letterSpacing: "0.05em", fontWeight: 700 }}>
                GOOD MORNING! 🌟
              </p>
              <h1 style={{ color: "#3a2856", fontFamily: "'Fredoka One', cursive", fontSize: "1.6rem", lineHeight: 1.2 }}>
                Pip's Storytime
              </h1>
            </div>
            {/* Reading streak badge */}
            <div
              className="flex items-center gap-1 px-3 py-1.5 rounded-full shadow-sm"
              style={{ background: "#fff7e6", border: "2px solid #ffd166" }}
            >
              <Star className="w-4 h-4" style={{ color: "#ffd166", fill: "#ffd166" }} />
              <span style={{ color: "#b8860b", fontSize: "0.8rem", fontWeight: 800 }}>7 day streak!</span>
            </div>
          </div>

          {/* Robot Mascot */}
          <motion.div
            className="flex flex-col items-center gap-1"
            initial={{ y: -10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, type: "spring", bounce: 0.4 }}
          >
            <div className="w-32 h-36 drop-shadow-lg">
              <PipRobot />
            </div>
            {/* Speech bubble */}
            <motion.div
              className="relative px-4 py-2.5 rounded-2xl shadow-sm max-w-[240px] text-center"
              style={{ background: "#ffffff", border: "2px solid #e9d5ff" }}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.25, duration: 0.35 }}
            >
              {/* Speech bubble tail */}
              <div
                className="absolute -top-3 left-1/2 -translate-x-1/2 w-0 h-0"
                style={{
                  borderLeft: "8px solid transparent",
                  borderRight: "8px solid transparent",
                  borderBottom: "12px solid #e9d5ff",
                }}
              />
              <div
                className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0"
                style={{
                  borderLeft: "7px solid transparent",
                  borderRight: "7px solid transparent",
                  borderBottom: "11px solid #ffffff",
                }}
              />
              <p style={{ color: "#7c3aed", fontSize: "0.82rem", fontWeight: 700 }}>
                Hi! I'm Pip! Ready for an adventure? 🚀
              </p>
            </motion.div>
          </motion.div>

          {/* Story Card */}
          <motion.div
            className="rounded-3xl p-5 shadow-lg relative overflow-hidden"
            style={{ background: "#ffffff", border: "2px solid #e9d5ff" }}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.4 }}
          >
            {/* Decorative corner stars on card */}
            <StarDecor className="absolute top-3 right-3 w-5 h-5 opacity-40" color="#ffd166" />
            <StarDecor className="absolute bottom-3 left-3 w-4 h-4 opacity-30" color="#a78bfa" />

            <div className="flex items-center gap-2 mb-3">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center shadow-sm"
                style={{ background: "linear-gradient(135deg, #a78bfa, #7c3aed)" }}
              >
                <BookOpen className="w-4 h-4 text-white" />
              </div>
              <div>
                <p style={{ color: "#7b5ea7", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.04em" }}>TODAY'S STORY</p>
                <p style={{ color: "#3a2856", fontSize: "0.9rem", fontFamily: "'Fredoka One', cursive" }}>Pip's Lost Gear</p>
              </div>
              <div className="ml-auto">
                <button
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-transform hover:scale-110 active:scale-95"
                  style={{ background: "#f0e6ff" }}
                  aria-label="Listen to story"
                >
                  <Volume2 className="w-4 h-4" style={{ color: "#7c3aed" }} />
                </button>
              </div>
            </div>

            {/* Story text */}
            <p
              className="leading-relaxed"
              style={{ color: "#4a3570", fontSize: "0.92rem", fontWeight: 400 }}
            >
              Once upon a time, a clever little robot named{" "}
              <span style={{ color: "#7c3aed", fontWeight: 700 }}>Pip</span>{" "}
              lost his{" "}
              <span
                className="inline-block px-1.5 py-0.5 rounded-lg"
                style={{ background: "#dbeafe", color: "#1d4ed8", fontWeight: 700 }}
              >
                shiny blue gear
              </span>{" "}
              in the{" "}
              <span style={{ color: "#065f46", fontWeight: 700 }}>Whispering Woods</span>
              ...
            </p>

            {/* Progress bar */}
            <div className="mt-4 flex items-center gap-2">
              <div className="flex-1 h-2 rounded-full" style={{ background: "#f0e6ff" }}>
                <div className="h-2 rounded-full" style={{ width: "30%", background: "linear-gradient(90deg, #a78bfa, #7c3aed)" }} />
              </div>
              <span style={{ color: "#7b5ea7", fontSize: "0.72rem", fontWeight: 700 }}>30%</span>
            </div>
          </motion.div>

          {/* Read Me a Story Button */}
          <motion.button
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-3 shadow-lg transition-transform active:scale-95"
            style={{
              background: "linear-gradient(135deg, #ff6b5b, #ff4757)",
              boxShadow: "0 6px 0 #c94040, 0 8px 16px rgba(255,71,87,0.35)",
              color: "#ffffff",
              fontFamily: "'Fredoka One', cursive",
              fontSize: "1.25rem",
              letterSpacing: "0.02em",
              border: "none",
              cursor: "pointer",
            }}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.45, duration: 0.4 }}
            whileTap={{ scale: 0.96, boxShadow: "0 2px 0 #c94040, 0 4px 8px rgba(255,71,87,0.25)" }}
            aria-label="Read Me a Story"
          >
            <BookOpen className="w-6 h-6" />
            Read Me a Story!
            <ChevronRight className="w-5 h-5" />
          </motion.button>

          {/* Quiz Section */}
          <motion.div
            className="rounded-3xl p-5 shadow-lg"
            style={{ background: "#ffffff", border: "2px solid #e9d5ff" }}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.55, duration: 0.4 }}
          >
            {/* Quiz header */}
            <div className="flex items-center gap-2 mb-1">
              <span style={{ fontSize: "1.3rem" }}>🧠</span>
              <p style={{ color: "#7b5ea7", fontSize: "0.72rem", fontWeight: 700, letterSpacing: "0.05em" }}>
                STORY QUIZ
              </p>
            </div>
            <p
              className="mb-4"
              style={{ color: "#3a2856", fontFamily: "'Fredoka One', cursive", fontSize: "1.02rem", lineHeight: 1.4 }}
            >
              What colour was Pip the Robot's lost gear?
            </p>

            {/* Answer buttons grid */}
            <div className="grid grid-cols-2 gap-3">
              {QUIZ_OPTIONS.map((opt, i) => {
                const isSelected = selected === opt.label;
                const isRight = opt.label === "Blue";
                let stateStyle = {};
                let emoji = "";

                if (revealed && isSelected) {
                  stateStyle = isCorrect
                    ? { outline: "3px solid #22c55e", outlineOffset: "2px" }
                    : { outline: "3px solid #ef4444", outlineOffset: "2px", opacity: 0.75 };
                  emoji = isCorrect ? " ✓" : " ✗";
                } else if (revealed && isRight) {
                  stateStyle = { outline: "3px solid #22c55e", outlineOffset: "2px" };
                }

                return (
                  <motion.button
                    key={opt.label}
                    className="py-3.5 rounded-2xl flex items-center justify-center shadow-md transition-transform"
                    style={{
                      background: opt.bg,
                      boxShadow: `0 4px 0 ${opt.shadow}, 0 6px 12px ${opt.bg}55`,
                      color: opt.text,
                      fontFamily: "'Fredoka One', cursive",
                      fontSize: "1.1rem",
                      border: "none",
                      cursor: revealed ? "default" : "pointer",
                      ...stateStyle,
                    }}
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.6 + i * 0.07, duration: 0.3, type: "spring", bounce: 0.3 }}
                    whileTap={!revealed ? { scale: 0.94 } : {}}
                    onClick={() => handleAnswer(opt.label)}
                    aria-label={`Answer: ${opt.label}`}
                    aria-pressed={isSelected}
                  >
                    {opt.label}{emoji}
                  </motion.button>
                );
              })}
            </div>

            {/* Feedback message */}
            {revealed && (
              <motion.div
                className="mt-4 py-3 px-4 rounded-2xl text-center"
                style={{
                  background: isCorrect ? "#dcfce7" : "#fef2f2",
                  border: `2px solid ${isCorrect ? "#86efac" : "#fecaca"}`,
                }}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", bounce: 0.4 }}
              >
                <p style={{
                  color: isCorrect ? "#166534" : "#991b1b",
                  fontFamily: "'Fredoka One', cursive",
                  fontSize: "1rem",
                }}>
                  {isCorrect
                    ? "🎉 Amazing! That's correct! Pip's gear was Blue!"
                    : "🤔 Not quite! Pip's gear was shiny Blue!"}
                </p>
              </motion.div>
            )}
          </motion.div>

          {/* Bottom nav hint */}
          <div className="flex justify-center gap-2 pt-1">
            {["📚", "🏆", "🎮", "👤"].map((icon, i) => (
              <button
                key={i}
                className="flex flex-col items-center gap-0.5 px-4 py-2 rounded-2xl transition-colors"
                style={{ background: i === 0 ? "#f0e6ff" : "transparent" }}
                aria-label={["Stories", "Trophies", "Games", "Profile"][i]}
              >
                <span style={{ fontSize: "1.3rem" }}>{icon}</span>
                <span style={{
                  fontSize: "0.6rem",
                  fontWeight: 700,
                  color: i === 0 ? "#7c3aed" : "#9ca3af",
                  letterSpacing: "0.03em",
                }}>
                  {["Stories", "Trophies", "Games", "Profile"][i]}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
