
  # Design Pip's Storytime Screen Mahasree

  This is a code bundle for Design Pip's Storytime Screen Mahasree. The original project is available at https://www.figma.com/design/1Nrf3pakdSHPLivaZdMYiM/Design-Pip-s-Storytime-Screen-Mahasree.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  